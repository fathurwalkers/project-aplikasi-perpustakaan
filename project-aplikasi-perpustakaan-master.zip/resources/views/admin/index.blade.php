@extends('layouts.admin-layout')

@section('title', 'Beranda')

@push('css')
    
@endpush

@section('main-header', 'Dashboard Panel')

@section('main-content')

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <p>Halaman Beranda - Index Page</p>
    </div>
</div>

@endsection



@push('js')
    
@endpush