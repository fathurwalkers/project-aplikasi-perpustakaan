<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Daftar Buku'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <?php if(session('berhasil_tambah')): ?>
            <div class="alert alert-success">
                <?php echo e(session('berhasil_tambah')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">

        <table id="table1" class="table table-bordered" style="width:100%">
            <thead class="thead-dark">
                <tr>
                    <td class="text-center">No</td>
                    <td class="">Judul Buku</td>
                    <td class="">Kode Buku</td>
                    <td class="">Penulis</td>
                    <td class="">Penerbit</td>
                    <td class="">Tahun Terbit</td>
                    <td class="">Kategori</td>
                    <td class="">Aksi</td>
                </tr>
            </thead>

            <tbody class="text-dark">

                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(Str::limit($item->buku_judul, 15)); ?></td>
                        <td class="text-center"><?php echo e($item->buku_kodekategori); ?></td>
                        <td><?php echo e($item->buku_penulis); ?></td>
                        <td><?php echo e(Str::limit($item->buku_penerbit, 15)); ?></td>
                        <td class="text-center"><?php echo e($item->buku_tahunterbit); ?></td>
                        
                            
                                
                            
                            
                            
                        
                            <td><?php echo e($item->kategori->kategori_nama); ?></td>
                        <td>
                            <div class="container">
                                <div class="row mx-auto d-flex justify-content-center btn-group">
                                    <div class="col-sm-12 col-md-12 col-lg-12 mx-auto d-flex justify-content-center btn-group">

                                        <button class="btn btn-sm btn-info rounded mr-1" onclick="location.href = '<?php echo e(route('lihat-buku', $item->id)); ?>';">
                                            <i class="fas fa-edit"></i>
                                            Lihat
                                        </button>

                                        <form action="<?php echo e(route('edit-buku', $item->id)); ?>" method="get">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-primary rounded mr-1">
                                                <i class="fas fa-edit"></i>
                                                Edit
                                            </button>
                                        </form>

                                        <a class="btn btn-sm btn-danger rounded" data-toggle="modal" data-target="#logoutModal<?php echo e($item->id); ?>">
                                            <i class="fas fa-edit"></i>
                                            Hapus
                                        </a>

                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>

                    <div class="modal fade" id="logoutModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Ingin meghapus Buku ini?</h5>
                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">Apakah anda yakin ingin menghapus buku ini?</div>
                                <div class="modal-footer">
                                    <button class="btn btn-info" type="button" data-dismiss="modal">Tidak</button>
                                    <form action="<?php echo e(route('hapus-buku', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Ya</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
<script>
    $(document).ready( function () {
        $('#table1').DataTable();
    } );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/daftar-buku.blade.php ENDPATH**/ ?>