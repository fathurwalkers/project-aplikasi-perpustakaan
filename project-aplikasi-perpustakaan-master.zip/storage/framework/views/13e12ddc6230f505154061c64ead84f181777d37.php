<?php $__env->startSection('title', 'Daftar Pinjaman'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Daftar Pinjaman'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <?php if(session('berhasil_tambah')): ?>
            <div class="alert alert-success">
                <?php echo e(session('berhasil_tambah')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">

        <table id="table1" class="table table-bordered" style="width:100%">
            <thead class="thead-dark">
                <tr>
                    <td class="text-center">No</td>
                    <td class="">Kode Pinjaman</td>
                    <td class="">Nama Peminjam</td>
                    <td class="">Tanggal Pinjam</td>
                    <td class="">Tanggal Kembali</td>
                    <td class="">Status Pinjaman</td>
                    <td class="">Aksi</td>
                </tr>
            </thead>

            <tbody class="text-dark">
                <?php $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->pinjaman_kode); ?></td>
                        <td><?php echo e($item->pinjaman_pengguna); ?></td>
                        <td><?php echo e(date("D / m / Y", strtotime($item->tanggal_pinjam))); ?></td>

                        <?php if($item->tanggal_kembali == null): ?>
                            <td>Belum Kembali</td>
                        <?php else: ?>
                            <td><?php echo e(date("D / m / Y", strtotime($item->tanggal_kembali))); ?></td>
                        <?php endif; ?>

                        <?php if($item->pinjaman_status == "PENDING"): ?>
                            <td class="">
                                <div class="row mx-auto d-flex justify-content-center">
                                <button class="badge badge-danger" type="button"><?php echo e($item->pinjaman_status); ?></button>
                                </div>
                            </td>
                        <?php elseif($item->pinjaman_status == "AKTIF"): ?>
                            <td>
                                <div class="row mx-auto d-flex justify-content-center">
                                <button class="badge badge-success" type="button"><?php echo e($item->pinjaman_status); ?></button>
                                </div>
                            </td>
                        <?php elseif($item->pinjaman_status == "BERAKHIR"): ?>
                            <td>
                                <div class="row mx-auto d-flex justify-content-center">
                                <button class="badge badge-primary" type="button"><?php echo e($item->pinjaman_status); ?></button>
                                </div>
                            </td>
                        <?php endif; ?>

                        <td>
                            <div class="row mx-auto d-flex justify-content-center">

                                <?php if($item->pinjaman_status == "PENDING"): ?>
                                    <?php if($users->login_level == 'admin'): ?>
                                        <form action="<?php echo e(route('konfirmasi-pinjaman')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="pinjaman_id" value="<?php echo e($item->id); ?>">
                                            <button type="submit" class="btn btn-sm btn-info rounded mr-1">Konfirmasi</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if($users->login_level == 'user'): ?>
                                    <?php if($item->pinjaman_status !== "BERAKHIR" && $item->pinjaman_status !== "PENDING"): ?>
                                    <form action="<?php echo e(route('konfirmasi-pengembalian')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="pinjaman_id" value="<?php echo e($item->id); ?>">
                                        <button type="submit" class="btn btn-sm btn-primary rounded mr-1">Pengembalian</button>
                                    </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if($users->login_level == 'admin'): ?>
                                    <form action="<?php echo e(route('hapus-pinjaman')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="pinjaman_id" value="<?php echo e($item->id); ?>">
                                        <button class="btn btn-sm btn-danger rounded">Hapus</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
<script>
    $(document).ready( function () {
        $('#table1').DataTable();
    } );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/daftar-pinjaman.blade.php ENDPATH**/ ?>