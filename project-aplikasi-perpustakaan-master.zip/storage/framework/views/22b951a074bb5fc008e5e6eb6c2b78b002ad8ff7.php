<?php $__env->startSection('title', 'Daftar Kategori'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Daftar Kategori'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <?php if(session('berhasil_tambah')): ?>
            <div class="alert alert-info">
                <?php echo e(session('berhasil_tambah')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">

        <table id="table1" class="table table-bordered" style="width:100%">
            <thead class="thead-dark">
                <tr>
                    <td class="text-center">No</td>
                    <td class="">Kategori</td>
                    <td class="">Kode Kategori</td>
                    <td class="">Aksi</td>
                </tr>
            </thead>

            <tbody class="text-dark">
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->kategori_nama); ?></td>
                        <td class="text-center"><?php echo e($item->kategori_kode); ?></td>
                        <td>
                            <div class="row mx-auto d-flex justify-content-center">
                                
                                
                                <button class="btn btn-sm btn-danger rounded" data-toggle="modal" data-target="#hapusModal<?php echo e($item->id); ?>">Hapus</button>
                            </div>
                        </td>

                        <div class="modal fade" id="hapusModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">Apakah anda yakin ingin keluar dari panel ini?</div>
                                    <div class="modal-footer">
                                        <button class="btn btn-info" type="button" data-dismiss="modal">Tidak</button>
                                        <form action="<?php echo e(route('hapus-kategori', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger">Ya</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
<script>
    $(document).ready( function () {
        $('#table1').DataTable();
    } );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/daftar-kategori.blade.php ENDPATH**/ ?>