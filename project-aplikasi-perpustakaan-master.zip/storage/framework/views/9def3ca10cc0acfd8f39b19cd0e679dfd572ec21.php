<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Profile - Pengguna'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row mx-auto">
    <div class="col-sm-2 col-md-2 col-lg-2">
        ​<img src="<?php echo e(asset('assets/default-avatar.jpg')); ?>" class="img-fluid img-thumbnail" width="200px">
    </div>
    <div class="col-sm-2 col-md-2 col-lg-2">
        <P class="text-dark"> 
            Nama Lengkap <br>
            Email <br>
            Username <br>
            Telepon <br>
            Status                                
        </P>    
    </div>
    <div class="col-sm-8 col-md-8 col-lg-8">
        <p class="text-dark">
            : <?php echo e($users->login_nama); ?> <br>
            : <?php echo e($users->login_email); ?> <br>
            : <?php echo e($users->login_username); ?> <br>
            : <?php echo e($users->login_telepon); ?> <br>
            : <span class="badge badge-success"><?php echo e($users->login_status); ?></span>
        </p>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/profile.blade.php ENDPATH**/ ?>