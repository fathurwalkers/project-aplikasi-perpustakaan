<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Profile - Pengguna'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row mx-auto">
    <div class="col-sm-2 col-md-2 col-lg-2">
        
    </div>
    <div class="col-sm-2 col-md-2 col-lg-2">
        <P class="text-dark"> 
            Judul Buku <br>
            Kode Buku <br>
            Kategori <br>
            Penulis <br>
            Penerbit <br>                                
            Tahun Terbit <br>                                
            Jumlah Halaman <br>                                
        </P>    
    </div>
    <div class="col-sm-6 col-md-6 col-lg-6">
        <p class="text-dark">
            : <?php echo e($buku->buku_judul); ?> <br>
            : <?php echo e($buku->buku_kodekategori); ?> <br>
            : <?php echo e($buku->kategori->kategori_nama); ?> <br>
            : <?php echo e($buku->buku_penulis); ?> <br>
            : <?php echo e($buku->buku_penerbit); ?> <br>
            : <?php echo e($buku->buku_tahunterbit); ?> <br>
            : <?php echo e($buku->buku_jumlahhalaman); ?> <br>
            
        </p>
    </div>
    <div class="col-sm-2 col-md-2 col-lg-2">

    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/lihat-buku.blade.php ENDPATH**/ ?>