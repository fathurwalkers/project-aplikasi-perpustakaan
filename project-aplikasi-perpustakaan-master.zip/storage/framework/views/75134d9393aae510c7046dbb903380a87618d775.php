<?php $__env->startSection('title', 'Halaman Tambah Kategori'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Tambah Kategori'); ?>

<?php $__env->startSection('main-content'); ?>


<form action="<?php echo e(route('post-tambah-kategori')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">

        <div class="col-sm-6 col-md-6 col-lg-6">
            <div class="form-group">
                <label for="kategori_nama" class="text-bold text-dark"><span style="color:#ff0000">* </span>Nama Kategori : </label>
                <input type="text" class="form-control text-bold text-dark border-1 border-dark" id="kategori_nama" aria-describedby="kategori_nama" placeholder="Masukkan Nama Kategori..." name="kategori_nama" autofocus>
                <small id="kategori_nama" class="form-text text-muted text-bold text-dark">Contoh : Teknologi dan Informasi </small>
            </div>
        </div>

        <div class="col-sm-6 col-md-6 col-lg-6">
            <div class="form-group">
                <label for="kategori_kode" class="text-bold text-dark"><span style="color:#ff0000">* </span>Kode Kategori : </label>
                <input type="text" class="form-control text-bold text-dark border-1 border-dark" id="kategori_kode" aria-describedby="kategori_kode" placeholder="Masukkan Kode Kategori..." name="kategori_kode">
                <small id="kategori_kode" class="form-text text-muted text-bold text-dark">Contoh : 700</small>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 mt-2">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                        <button type="submit" class="btn btn-md btn-success border-dark shadow">KONFIRMASI</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                        <small id="" class="form-text text-muted text-bold text-dark">Tekan tombol "KONFIRMASI" untuk menyelesaikan proses input data Kategori baru.</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

</form>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/tambah-kategori.blade.php ENDPATH**/ ?>