<?php $__env->startSection('title', 'Daftar Pengguna'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Daftar Pengguna'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">

        <table id="table1" class="table table-bordered" style="width:100%">
            <thead class="thead-dark">
                <tr>
                    <td class="text-center">No</td>
                    <td class="">Nama Pengguna</td>
                    <td class="">Username</td>
                    <td class="">Email</td>
                    <td class="">No Telepon</td>
                    <td class="">Menu Kelola</td>
                </tr>
            </thead>

            <tbody class="text-dark">
                <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                    <td class=""><?php echo e($item->login_nama); ?></td>
                    <td class=""><?php echo e($item->login_username); ?></td>
                    <td class=""><?php echo e($item->login_email); ?></td>
                    <td class=""><?php echo e($item->login_telepon); ?></td>
                    <td>
                        <div class="row mx-auto d-flex justify-content-center">
                            
                            <button class="btn btn-sm btn-primary rounded mr-1" data-toggle="modal" data-target="#modal_update<?php echo e($item->id); ?>">Edit</button>
                            <button class="btn btn-sm btn-danger rounded" data-toggle="modal" data-target="#modal_hapus<?php echo e($item->id); ?>">Hapus</button>

                            
                            <div class="modal fade" id="modal_update<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Ubah data Pengguna</h5>
                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>

                                        <form action="<?php echo e(route('update-pengguna', $item->id)); ?>" method="POST">
                                            <div class="modal-body">

                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <label for="login_nama" class="text-bold text-dark">
                                                            Nama Pengguna
                                                        </label>
                                                        <input type="text" class="form-control text-bold text-dark border-1 border-dark" id="login_nama" aria-describedby="login_nama" name="login_nama" autofocus value="<?php echo e($item->login_nama); ?>">
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <label for="login_email" class="text-bold text-dark">
                                                            Email
                                                        </label>
                                                        <input type="text" class="form-control text-bold text-dark border-1 border-dark" id="login_email" aria-describedby="login_email" name="login_email" autofocus value="<?php echo e($item->login_email); ?>">
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <label for="login_telepon" class="text-bold text-dark">
                                                            No. HP / Telepon
                                                        </label>
                                                        <input type="text" class="form-control text-bold text-dark border-1 border-dark" id="login_telepon" aria-describedby="login_telepon" name="login_telepon" autofocus value="<?php echo e($item->login_telepon); ?>">
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-info" type="button" data-dismiss="modal">Tidak</button>

                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-danger">Ya</button>

                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>

                            
                            <div class="modal fade" id="modal_hapus<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Ingin meghapus Buku ini?</h5>
                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">Apakah anda yakin ingin menghapus buku ini?</div>
                                        <div class="modal-footer">
                                            <button class="btn btn-info" type="button" data-dismiss="modal">Tidak</button>
                                            <form action="<?php echo e(route('hapus-pengguna', $item->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger">Ya</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
<script>
    $(document).ready( function () {
        $('#table1').DataTable();
    } );
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/daftar-pengguna.blade.php ENDPATH**/ ?>