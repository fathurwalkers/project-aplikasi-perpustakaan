<?php $__env->startSection('title', 'Daftar Pengguna'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Daftar Pengguna'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">

        <table id="table1" class="table table-bordered" style="width:100%">
            <thead class="thead-dark">
                <tr>
                    <td class="text-center">No</td>
                    <td class="">Nama Pengguna</td>
                    <td class="">Username</td>
                    <td class="">Email</td>
                    <td class="">No Telepon</td>
                    <td class="">Menu Kelola</td>
                </tr>
            </thead>
            
            <tbody class="text-dark">
                <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                    <td class=""><?php echo e($item->login_nama); ?></td>
                    <td class=""><?php echo e($item->login_username); ?></td>
                    <td class=""><?php echo e($item->login_email); ?></td>
                    <td class=""><?php echo e($item->login_telepon); ?></td>
                    <td>
                        <div class="row mx-auto d-flex justify-content-center">
                            <button class="btn btn-sm btn-info rounded mr-1">Lihat</button>
                            <button class="btn btn-sm btn-primary rounded mr-1">Edit</button>
                            <button class="btn btn-sm btn-danger rounded">Hapus</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>

    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
<script>
    $(document).ready( function () {
        $('#table1').DataTable();
    } );
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/daftar-pengguna.blade.php ENDPATH**/ ?>