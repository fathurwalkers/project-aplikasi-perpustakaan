<?php $__env->startSection('title', 'Halaman Buat Pinjaman'); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
<script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-header', 'Buat Pinjaman'); ?>

<?php $__env->startSection('main-content'); ?>


<form action="<?php echo e(route('post-tambah-pinjaman')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">

        <div class="col-sm-6 col-md-6 col-lg-6">
            <div class="form-group">
                <label for="pinjaman_pengguna" class="text-bold text-dark"><span style="color:#ff0000">* </span>Nama Peminjam : </label>
                <input type="text" class="form-control text-bold text-dark border-1 border-dark" id="pinjaman_pengguna" aria-describedby="pinjaman_pengguna" placeholder="Masukkan Nama Kategori..." value="<?php echo e($users->login_nama); ?>" name="pinjaman_pengguna" readonly>
                <small id="pinjaman_pengguna" class="form-text text-muted text-bold text-dark">Contoh : Teknologi dan Informasi </small>
            </div>
        </div>

        <div class="col-sm-6 col-md-6 col-lg-6"> 
            <label for="id_buku" class="text-bold text-dark"><span style="color:#ff0000">* </span>Pilih Buku : </label>
            <select id="choices-multiple-remove-button" placeholder="Pilih buku yang akan dipinjam..." name="id_buku[]" multiple>
                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->buku_judul); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select> 
        </div>

    </div>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 mt-2">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                        <button type="submit" class="btn btn-md btn-success border-dark shadow">KONFIRMASI</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                        <small id="" class="form-text text-muted text-bold text-dark">Tekan tombol "KONFIRMASI" untuk menyelesaikan proses input data Kategori baru.</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

</form>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function(){
        var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
            removeItemButton: true,
            maxItemCount:100,
            searchResultLimit:100,
            renderChoiceLimit:100
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\project-aplikasi-perpustakaan-master\resources\views/admin/tambah-pinjaman.blade.php ENDPATH**/ ?>